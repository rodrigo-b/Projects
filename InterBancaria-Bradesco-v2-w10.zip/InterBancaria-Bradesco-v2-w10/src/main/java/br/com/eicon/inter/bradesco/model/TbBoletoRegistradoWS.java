package br.com.eicon.inter.bradesco.model;

import java.util.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name = "tb_boleto_registrado_ws")
@NamedQueries({
    @NamedQuery(name = "TbBoletoRegistradoWS.buscarBoletoPendenteEnvio", query = "SELECT t FROM TbBoletoRegistradoWS t where t.statusEnvioBoleto is null AND t.codBanco = 237 order by t.dataRegistro asc"),
    @NamedQuery(name = "TbBoletoRegistradoWS.buscarBoletoIndividual", query="SELECT t FROM TbBoletoRegistradoWS t where t.ticket =:tiquet AND t.codBanco = 237")
})
public class TbBoletoRegistradoWS {

	public static final String NQ_PEND_ENV = "TbBoletoRegistradoWS.buscarBoletoPendenteEnvio";
	public static final String NQ_INDIV = "TbBoletoRegistradoWS.buscarBoletoIndividual";
	
	  @Id
	  @GeneratedValue(generator="seq_boleto_registrado", strategy=GenerationType.SEQUENCE)
	  @SequenceGenerator(name="seq_boleto_registrado", sequenceName="seq_boleto_registrado", allocationSize=1)
	  @Column(name="ID")
	  private Long ticket;
	  
	  @Column(name="DATA_REGISTRO")
	  @Temporal(TemporalType.TIMESTAMP)
	  private Date dataRegistro;
	  
	  @Column(name=" cod_sistema")
	  private Integer codSistema;
	  
	  @Column(name=" cod_cliente")
	  private Integer codCliente;
	  
	  @Column(name=" cod_banco")
	  private Integer codBanco;
	  
	  @Column(name="operacao")
	  private String operacao;
	  
	  @Column(name="status_envio_boleto")
	  private Integer statusEnvioBoleto;
	  
	  @Column(name="dados_envio_boleto")
	  private String dadosEnvioBoleto;
	  
	  @Column(name="data_envio_boleto")
	  @Temporal(TemporalType.TIMESTAMP)
	  private Date dataEnvioBoleto;
	  
	  @Column(name="DETALHES_ENVIO_BOLETO")
	  private String detalhesEnvioBoleto;
	  
	  @Column(name="status_retorno_origem")
	  private Integer statusRetornoOrigem;
	  
	  @Column(name="dados_retorno_boleto")
	  private String dadosRetornoBoleto;
	  
	  @Column(name="data_retorno_origem")
	  @Temporal(TemporalType.TIMESTAMP)
	  private Date dataRetornoOrigem;
	  
	  @Column(name="DETALHES_RETORNO_ORIGEM")
	  private String detalhesRetornoOrigem;
	  
	  @Column(name="ID_SOLICITACAO")
	  private Long codSolicitacao;
	  
	  
	  public Long getTicket()  {
		return ticket;
	  }
		  
	  public void setTicket(Long ticket) {
		this.ticket = ticket;
	  }
	  
	  public Date getDataRegistro() {
	    return dataRegistro;
	  }
	  
	  public void setDataRegistro(Date dataRegistro) {
	    this.dataRegistro = dataRegistro;
	  }
	  
	  public Integer getCodSistema() {
	    return codSistema;
	  }
	  
	  public void setCodSistema(Integer codSistema) {
	    this.codSistema = codSistema;
	  }
	  
	  public Integer getCodCliente() {
	    return codCliente;
	  }
	  
	  public void setCodCliente(Integer codCliente) {
	    this.codCliente = codCliente;
	  }
	  
	  public Integer getCodBanco() {
	    return codBanco;
	  }
	  
	  public void setCodBanco(Integer codBanco) {
	    this.codBanco = codBanco;
	  }
	  
	  public String getOperacao() {
	    return operacao;
	  }
	  
	  public void setOperacao(String operacao) {
	    this.operacao = operacao;
	  }
	  
	  public Integer getStatusEnvioBoleto() {
	    return statusEnvioBoleto;
	  }
	  
	  public void setStatusEnvioBoleto(Integer statusEnvioBoleto) {
	    this.statusEnvioBoleto = statusEnvioBoleto;
	  }
	  
	  public String getDadosEnvioBoleto() {
	    return dadosEnvioBoleto;
	  }
	  
	  public void setDadosEnvioBoleto(String dadosEnvioBoleto) {
	    this.dadosEnvioBoleto = dadosEnvioBoleto;
	  }
	  
	  public Date getDataEnvioBoleto() {
	    return dataEnvioBoleto;
	  }
	  
	  public void setDataEnvioBoleto(Date dataEnvioBoleto) {
	    this.dataEnvioBoleto = dataEnvioBoleto;
	  }
	  
	  public String getDetalhesEnvioBoleto() {
	    return detalhesEnvioBoleto;
	  }
	  
	  public void setDetalhesEnvioBoleto(String detalhesEnvioBoleto) {
	    this.detalhesEnvioBoleto = detalhesEnvioBoleto;
	  }
	  
	  public Integer getStatusRetornoOrigem() {
	    return statusRetornoOrigem;
	  }
	  
	  public void setStatusRetornoOrigem(Integer statusRetornoOrigem) {
	    this.statusRetornoOrigem = statusRetornoOrigem;
	  }
	  
	  public String getDadosRetornoBoleto() {
	    return dadosRetornoBoleto;
	  }
	  
	  public void setDadosRetornoBoleto(String dadosRetornoBoleto) {
	    this.dadosRetornoBoleto = dadosRetornoBoleto;
	  }
	  
	  public Date getDataRetornoOrigem() {
	    return dataRetornoOrigem;
	  }
	  
	  public void setDataRetornoOrigem(Date dataRetornoOrigem) {
	    this.dataRetornoOrigem = dataRetornoOrigem;
	  }
	  
	  public String getDetalhesRetornoOrigem() {
	    return detalhesRetornoOrigem;
	  }
	  
	  public void setDetalhesRetornoOrigem(String detalhesRetornoOrigem) {
	    this.detalhesRetornoOrigem = detalhesRetornoOrigem;
	  }
	  
	  public Long getCodSolicitacao() {
	    return codSolicitacao;
	  }

	  public void setIdSolicitacao(Long codSolicitacao) {
		this.codSolicitacao = codSolicitacao;
	  }

	  public TbBoletoRegistradoWS() {}

}
