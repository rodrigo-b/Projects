package br.com.eicon.inter.bradesco.scheduler;

import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.inject.Inject;

import br.com.eicon.inter.bradesco.service.BoletoService;
import br.com.eicon.inter.bradesco.util.GenericsUtil;
import br.com.eicon.inter.bradesco.util.InfraEnum;
import br.com.eicon.logger.service.Logger;

@Singleton
public class Scheduler {

	@Inject
	private BoletoService boletoService;

	@Schedule(hour = "*/1", minute = "*/1",second = "*/10" , persistent=false)
	public void enviarPendente(){

		Logger.doLog(InfraEnum.COD_APP.getInt(), 0, 1, "registrarBoleto " + GenericsUtil.toString(new String[]{"hour=*","minute=*","second=*/10"}) , 3);
		
		boletoService.registrarBoleto();	
	}

}
