package br.com.eicon.inter.bradesco.util;

public enum InfraEnum {

	COD_APP("202");
	
	
	
    private String value;

    InfraEnum(String value) {
        this.value = value;
    }

    public String getString() {
        return this.value;
    }

    public Integer getInt() {
        return Integer.parseInt(this.value);
    }
    
}
