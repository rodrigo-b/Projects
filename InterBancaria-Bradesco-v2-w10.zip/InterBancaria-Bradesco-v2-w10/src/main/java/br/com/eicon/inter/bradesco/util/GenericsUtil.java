package br.com.eicon.inter.bradesco.util;

public class GenericsUtil {

	
	public static String parse(String requestResponse){
		
		
		int indiceInicioRequestResponse      = requestResponse.indexOf("<return>");
		
		int indiceFimRequestResponse =requestResponse.lastIndexOf("</return>");
		
		String requestResponseFinal = requestResponse.substring(indiceInicioRequestResponse + 8, indiceFimRequestResponse);
		
		return requestResponseFinal;
		
	}
	
	  public static String toString(String[] arrayString) {
		  
		  StringBuilder sb = new StringBuilder();
		  sb.append( "[");		  
		  for (String s : arrayString) {
			  sb.append( s+",");
		  }
		  sb.append( "]");
		  return sb.toString();
	  }
	
}
