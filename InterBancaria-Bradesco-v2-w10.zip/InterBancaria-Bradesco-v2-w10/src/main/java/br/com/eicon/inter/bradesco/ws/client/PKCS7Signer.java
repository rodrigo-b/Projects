package br.com.eicon.inter.bradesco.ws.client;

import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;


import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.bouncycastle.cert.jcajce.JcaCertStore;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.cms.CMSTypedData;
import org.bouncycastle.cms.jcajce.JcaSignerInfoGeneratorBuilder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.bouncycastle.operator.jcajce.JcaDigestCalculatorProviderBuilder;
import org.bouncycastle.util.Store;
import org.bouncycastle.util.encoders.Base64;

public final class PKCS7Signer {

	private static final String PATH_TO_KEYSTORE = "/shared/wildfly-10.0.0.Final/standalone/configuration/EICON2018.pfx";
	private static final String KEYSTORE_PASSWORD = "EICON@2018";
    private static final String SIGNATUREALGO = "SHA256WithRSA";
    private static final String URI_REGISTRO = "https://cobranca.bradesconetempresa.b.br/ibpjregistrotitulows/registrotitulo";
//    private static final String URI_REGISTRO = "https://cobranca.bradesconetempresa.b.br/ibpjregistrotitulows/registrotitulohomologacao";
    
    
    
    
    public  String enviarBoletos(String json) throws Exception {
        PKCS7Signer signer = new PKCS7Signer();
        KeyStore keyStore = signer.loadKeyStore();
        CMSSignedDataGenerator signatureGenerator = signer.setUpProvider(keyStore);
        
        byte[] signedBytes = signer.signPkcs7(json.getBytes("utf-8"), signatureGenerator);
        
        HttpEntity entity = new StringEntity(new String(Base64.encode(signedBytes)), Charset.forName("utf-8"));
		HttpPost post = new HttpPost(URI_REGISTRO);
		post.setEntity(entity);
		
		
		RequestConfig.Builder requestBuilder = RequestConfig.custom();
		
		requestBuilder.setConnectTimeout(10000);
		requestBuilder.setConnectionRequestTimeout(10000);
		requestBuilder.setSocketTimeout(10000);
		
		HttpClientBuilder builder = HttpClientBuilder.create();
		builder.setDefaultRequestConfig(requestBuilder.build());
		
		HttpResponse response = builder.build().execute(post);
	
		String responseString = EntityUtils.toString(response.getEntity(), "utf-8"); 
		
		responseString = trataCaracteresEspeciais(responseString);
		
		return responseString;
    }
    
    private KeyStore loadKeyStore() throws Exception {
    	KeyStore keystore = KeyStore.getInstance("JKS");
        
        InputStream is = new FileInputStream(PATH_TO_KEYSTORE);
        keystore.load(is, KEYSTORE_PASSWORD.toCharArray());
        return keystore;
    }

    private CMSSignedDataGenerator setUpProvider(final KeyStore keystore) throws Exception {
        Security.addProvider(new BouncyCastleProvider());
        
        Enumeration<String> aliases = keystore.aliases();
		String aliaz = "";
		while (aliases.hasMoreElements()) {
			aliaz = aliases.nextElement();
			if (keystore.isKeyEntry(aliaz)) {
				break;
			}
		}
        Certificate[] certchain = (Certificate[]) keystore.getCertificateChain(aliaz);

        final List<Certificate> certlist = new ArrayList<Certificate>();

        for (int i = 0, length = certchain == null ? 0 : certchain.length; i < length; i++) {
            certlist.add(certchain[i]);
        }

        Store certstore = new JcaCertStore(certlist);

        Certificate cert = keystore.getCertificate(aliaz);

        ContentSigner signer = new JcaContentSignerBuilder(SIGNATUREALGO).setProvider("BC").
                					build((PrivateKey) (keystore.getKey(aliaz, KEYSTORE_PASSWORD.toCharArray())));

        CMSSignedDataGenerator generator = new CMSSignedDataGenerator();

        generator.addSignerInfoGenerator(new JcaSignerInfoGeneratorBuilder(new JcaDigestCalculatorProviderBuilder().setProvider("BC").
        									build()).build(signer, (X509Certificate) cert));

        generator.addCertificates(certstore);

        return generator;
    }

    private byte[] signPkcs7(final byte[] content, final CMSSignedDataGenerator generator) throws Exception {
        CMSTypedData cmsdata = new CMSProcessableByteArray(content);
        CMSSignedData signeddata = generator.generate(cmsdata, true);
        return signeddata.getEncoded();
    }
    
    public String trataCaracteresEspeciais(String responseString){
    	responseString = responseString.replaceAll("&amp;", "");
		responseString = responseString.replaceAll("&ccedil;", "ç");
		responseString = responseString.replaceAll("&atilde;", "ã");
		responseString = responseString.replaceAll("&lt;", "<");
		responseString = responseString.replaceAll("&gt;", ">");
		responseString = responseString.replaceAll("&Ccedil;", "Ç");
		responseString = responseString.replaceAll("&ntilde;", "ñ");
		responseString = responseString.replaceAll("&Ntilde;", "Ñ");
		responseString = responseString.replaceAll("&uuml;", "ü");
		responseString = responseString.replaceAll("&Uuml;", "Ü");
		responseString = responseString.replaceAll("&ugrave;", "ù");
		responseString = responseString.replaceAll("&Ugrave;", "Ù");
		responseString = responseString.replaceAll("&ucirc;", "û");
		responseString = responseString.replaceAll("&Ucirc;", "Û");
		responseString = responseString.replaceAll("&uacute;", "ú");
		responseString = responseString.replaceAll("&Uacute;", "Ú");
		responseString = responseString.replaceAll("&ouml;", "ö");
		responseString = responseString.replaceAll("&Ouml;", "Ö");
		responseString = responseString.replaceAll("&otilde;", "õ");
		responseString = responseString.replaceAll("&Otilde;", "Õ");
		responseString = responseString.replaceAll("&ograve;", "ò");
		responseString = responseString.replaceAll("&Ograve;", "Ò");
		responseString = responseString.replaceAll("&ocirc;", "ô");
		responseString = responseString.replaceAll("&Ocirc;", "Ô");
		responseString = responseString.replaceAll("&oacute;", "ó");
		responseString = responseString.replaceAll("&Oacute;", "Ó");
		responseString = responseString.replaceAll("&iuml;", "ï");
		responseString = responseString.replaceAll("&Iuml;", "Ï");
		responseString = responseString.replaceAll("&igrave;", "ì");
		responseString = responseString.replaceAll("&Igrave;", "Ì");
		responseString = responseString.replaceAll("&icirc;", "î");
		responseString = responseString.replaceAll("&Icirc;", "Î");
		responseString = responseString.replaceAll("&iacute;", "í");
		responseString = responseString.replaceAll("&Iacute;", "Í");
		responseString = responseString.replaceAll("&euml;", "ë");
		responseString = responseString.replaceAll("&Euml;", "Ë");
		responseString = responseString.replaceAll("&egrave;", "è");
		responseString = responseString.replaceAll("&Egrave;", "È");
		responseString = responseString.replaceAll("&ecirc;", "ê");
		responseString = responseString.replaceAll("&Ecirc;", "Ê");
		responseString = responseString.replaceAll("&eacute;", "é");
		responseString = responseString.replaceAll("&Eacute;", "É");
		responseString = responseString.replaceAll("&auml;", "ä");
		responseString = responseString.replaceAll("&Auml;", "Ä");
		responseString = responseString.replaceAll("&atilde;", "ã");
		responseString = responseString.replaceAll("&Atilde;", "Ã");
		responseString = responseString.replaceAll("&agrave;", "à");
		responseString = responseString.replaceAll("&Agrave;", "À");
		responseString = responseString.replaceAll("&acirc;", "â");
		responseString = responseString.replaceAll("&Acirc;", "Â");
		responseString = responseString.replaceAll("&aacute;", "á");
		responseString = responseString.replaceAll("&Aacute;", "Á");
		
		responseString = responseString.replaceAll("amp;", "");
		responseString = responseString.replaceAll("ccedil;", "ç");
		responseString = responseString.replaceAll("atilde;", "ã");
		responseString = responseString.replaceAll("lt;", "<");
		responseString = responseString.replaceAll("gt;", ">");
		responseString = responseString.replaceAll("Ccedil;", "Ç");
		responseString = responseString.replaceAll("ntilde;", "ñ");
		responseString = responseString.replaceAll("Ntilde;", "Ñ");
		responseString = responseString.replaceAll("uuml;", "ü");
		responseString = responseString.replaceAll("Uuml;", "Ü");
		responseString = responseString.replaceAll("ugrave;", "ù");
		responseString = responseString.replaceAll("Ugrave;", "Ù");
		responseString = responseString.replaceAll("ucirc;", "û");
		responseString = responseString.replaceAll("Ucirc;", "Û");
		responseString = responseString.replaceAll("uacute;", "ú");
		responseString = responseString.replaceAll("Uacute;", "Ú");
		responseString = responseString.replaceAll("ouml;", "ö");
		responseString = responseString.replaceAll("Ouml;", "Ö");
		responseString = responseString.replaceAll("otilde;", "õ");
		responseString = responseString.replaceAll("Otilde;", "Õ");
		responseString = responseString.replaceAll("ograve;", "ò");
		responseString = responseString.replaceAll("Ograve;", "Ò");
		responseString = responseString.replaceAll("ocirc;", "ô");
		responseString = responseString.replaceAll("Ocirc;", "Ô");
		responseString = responseString.replaceAll("oacute;", "ó");
		responseString = responseString.replaceAll("Oacute;", "Ó");
		responseString = responseString.replaceAll("iuml;", "ï");
		responseString = responseString.replaceAll("Iuml;", "Ï");
		responseString = responseString.replaceAll("igrave;", "ì");
		responseString = responseString.replaceAll("Igrave;", "Ì");
		responseString = responseString.replaceAll("icirc;", "î");
		responseString = responseString.replaceAll("Icirc;", "Î");
		responseString = responseString.replaceAll("iacute;", "í");
		responseString = responseString.replaceAll("Iacute;", "Í");
		responseString = responseString.replaceAll("euml;", "ë");
		responseString = responseString.replaceAll("Euml;", "Ë");
		responseString = responseString.replaceAll("egrave;", "è");
		responseString = responseString.replaceAll("Egrave;", "È");
		responseString = responseString.replaceAll("ecirc;", "ê");
		responseString = responseString.replaceAll("Ecirc;", "Ê");
		responseString = responseString.replaceAll("eacute;", "é");
		responseString = responseString.replaceAll("Eacute;", "É");
		responseString = responseString.replaceAll("auml;", "ä");
		responseString = responseString.replaceAll("Auml;", "Ä");
		responseString = responseString.replaceAll("atilde;", "ã");
		responseString = responseString.replaceAll("Atilde;", "Ã");
		responseString = responseString.replaceAll("agrave;", "à");
		responseString = responseString.replaceAll("Agrave;", "À");
		responseString = responseString.replaceAll("acirc;", "â");
		responseString = responseString.replaceAll("Acirc;", "Â");
		responseString = responseString.replaceAll("aacute;", "á");
		responseString = responseString.replaceAll("Aacute;", "Á");
		
		return responseString;
    	
    }

}
