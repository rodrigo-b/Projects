package br.com.eicon.inter.bradesco.service;

import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import br.com.eicon.inter.bradesco.dao.GenericDAO;
import br.com.eicon.inter.bradesco.model.TbBoletoRegistradoWS;
import br.com.eicon.inter.bradesco.util.GenericsUtil;
import br.com.eicon.inter.bradesco.util.InfraEnum;
import br.com.eicon.inter.bradesco.ws.client.PKCS7Signer;
import br.com.eicon.logger.service.Logger;

@Stateless
public class BoletoService {

	@Inject
	GenericDAO<TbBoletoRegistradoWS> boletoRegistradoDAO;
	
	private PKCS7Signer pkcs7Signer;

	
	public void registrarBoleto(){

		pkcs7Signer = new PKCS7Signer();
		
		List<TbBoletoRegistradoWS> listaBoletosRegistrado = boletoRegistradoDAO.findByNamedQuery(TbBoletoRegistradoWS.NQ_PEND_ENV, 5);

		
		for(TbBoletoRegistradoWS tbBoletoRegistradoWS: listaBoletosRegistrado){
			
			String response = "";

			try {
				response = pkcs7Signer.enviarBoletos(tbBoletoRegistradoWS.getDadosEnvioBoleto());

				tbBoletoRegistradoWS.setDadosRetornoBoleto(GenericsUtil.parse(response));
				
				tbBoletoRegistradoWS.setDataEnvioBoleto(new Date());
				tbBoletoRegistradoWS.setDetalhesEnvioBoleto(response);
				tbBoletoRegistradoWS.setStatusEnvioBoleto(1);
				boletoRegistradoDAO.update(tbBoletoRegistradoWS);

				Logger.doLog(InfraEnum.COD_APP.getInt(),tbBoletoRegistradoWS.getCodCliente(),103, 1, tbBoletoRegistradoWS.getDadosEnvioBoleto(),tbBoletoRegistradoWS.getDadosRetornoBoleto(),"Sucesso",tbBoletoRegistradoWS.getTicket());
				
			} catch (Exception e) {

				tbBoletoRegistradoWS.setDataEnvioBoleto(new Date());
				tbBoletoRegistradoWS.setDetalhesEnvioBoleto(response);
				tbBoletoRegistradoWS.setStatusEnvioBoleto(2);
				boletoRegistradoDAO.update(tbBoletoRegistradoWS);

				Logger.doLog(InfraEnum.COD_APP.getInt(),tbBoletoRegistradoWS.getCodCliente(),103, 2, tbBoletoRegistradoWS.getDadosEnvioBoleto(),tbBoletoRegistradoWS.getDadosRetornoBoleto(),"Exception "+e.getMessage(), tbBoletoRegistradoWS.getTicket());
			}
		}
	}
	
}
