package br.com.interoperabilidade.boletos.bb.scheduler;

import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.inject.Inject;

import br.com.interoperabilidade.boletos.bb.service.EnviarService;

@Singleton
public class Scheduler {

	@Inject
	EnviarService enviar;
	
	@Schedule(hour="15", minute="38", second="40")
	public void enviarPendente(){
		
		enviar.enviarPendentes();
		
	}
	
	
}
