package br.com.interoperabilidade.boletos.bb;

public class Teste {

}
