package br.com.interoperabilidade.boletos.bb.service;

import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.List;

import javax.ejb.Schedule;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.core.MediaType;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.representation.Form;

import br.com.interoperabilidade.boletos.bb.dao.BoletosRegistradoDAO;
import br.com.interoperabilidade.boletos.bb.model.BoletosRegistrado;
import br.com.interoperabilidade.boletos.bb.resolver.DadosBoletoBancario;
import br.com.interoperabilidade.boletos.bb.util.ClientWebServiceUtil;
import br.com.interoperabilidade.boletos.bb.util.MarshallerDadosBoletoBancario;

import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.client.urlconnection.HTTPSProperties;
@Stateless
public class EnviarService {

	@Inject
	BoletosRegistradoDAO<BoletosRegistrado> boletosRegistradoDAO;
	
	@Inject
	ClientWebServiceUtil clientWebServiceUtil;
	
	@Inject
	MarshallerDadosBoletoBancario marshallerDadosBoletoBancario;
	
	static {
	    //for localhost testing only
	    javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(
	    new javax.net.ssl.HostnameVerifier(){

	        public boolean verify(String hostname,
	                javax.net.ssl.SSLSession sslSession) {
	            if (hostname.equals("https://mpag.bb.com.br/")) {
	                return true;
	            }
	            return false;
	        }
	    });
	}
	
	@Schedule
	public void enviarPendentes(){
		
//		List<BoletosRegistrado> listaBoletosRegistrados = boletosRegistradoDAO.findByNamedQuery(BoletosRegistrado.ENVIO_BB_PENDENTE);
//		
//		for(BoletosRegistrado boleto:listaBoletosRegistrados){
//			
//		}
		
//		String xml = marshallerDadosBoletoBancario.marshaller(listaBoletosRegistrados);
		
		
//		clientWebServiceUtil.realizaRequisiçãoEnvio(dadosBoletoBancario);
		
		DadosBoletoBancario dadosBoleto = new DadosBoletoBancario();
		dadosBoleto.setIdConv(316583L);
		dadosBoleto.setRefTran("30420659000000001");
		dadosBoleto.setValor(0.0);
		dadosBoleto.setDtVenc(21022018L);
		dadosBoleto.setTpPagamento(2L);
		dadosBoleto.setCpfCnpj("42212554669");
		dadosBoleto.setIndicadorPessoa(1L);
		dadosBoleto.setTpDuplicata("DS");
		dadosBoleto.setUrlRetorno("/retornoBoleto?id=30420659000000001");
		dadosBoleto.setNome("RODRIGO");
		dadosBoleto.setEndereco("Rua");
		dadosBoleto.setCidade("Taboão da serra");
		dadosBoleto.setUf("SP");
		dadosBoleto.setCep("06766520");
		dadosBoleto.setMsgLoga("TESTE");
		
		
		Form input = new Form();
		input.add("idConv", 316583);
		input.add("refTran", "30420659000000001");
		input.add("valor", 0);
		input.add("qtdPontos", null);
		input.add("dtVenc", 21022018);
		input.add("tpPagamento", 2);
		input.add("cpfCnpj", "53174058000118");
		input.add("indicadorPessoa", 1);
		input.add("valorDesconto", null);
		input.add("dataLimiteDesconto", null);
		input.add("tpDuplicata", "DS");
		input.add("urlRetorno", "/retornoBoleto?id=30420659000000001");
		input.add("urlInforma", null);
		input.add("nome", "RODRIGO");
		input.add("endereco", "Rua das olarias");
		input.add("cidade", "TAboao");
		input.add("uf", "SP");
		input.add("cep", "06766320");
		input.add("msgLoja", "TESTE");
		
		System.setProperty("javax.net.ssl.keyStoreType", "PKCS12");

		System.setProperty("javax.net.ssl.keyStore", "C:/CERTIFICADO_FULL.pfx");

		System.setProperty("javax.net.ssl.keyStorePassword", "changeit");
		
//		String certificatesTrustStorePath = "C:/Users/rcorreia/Desktop/ambiente/java/jdk1.8.0_144/jre/lib/security/cacerts";
//		System.setProperty("javax.net.ssl.trustStore", certificatesTrustStorePath);
		String teste = "";
//		System.out.println(objeto);
		
//		HostnameVerifier hostnameVerifier = HttpsURLConnection.getDefaultHostnameVerifier();
//		ClientConfig config = new DefaultClientConfig();
//		SSLContext ctx = SSLContext.getInstance("SSL");
//		ctx.init(null, myTrustManager, null);
//		config.getProperties().put(HTTPSProperties.PROPERTY_HTTPS_PROPERTIES, new HTTPSProperties(hostnameVerifier, ctx));
//		Client client = Client.create(config);
		
		Client client =   createClient();//Client.create();
		WebResource webResource = client.resource("https://mpag.bb.com.br/site/mpag/");
		ClientResponse response = webResource.type(MediaType.APPLICATION_FORM_URLENCODED).post(ClientResponse.class, teste);
		System.out.println(response.getEntity(ClientResponse.class).getClientResponseStatus());
	}
	
	public static ClientConfig configureClient() {
		TrustManager[ ] certs = new TrustManager[ ] {
	            new X509TrustManager() {

	            	public X509Certificate[] getAcceptedIssuers() {
						return null;
					}

					public void checkServerTrusted(X509Certificate[] chain, String authType)
							throws CertificateException {
					}
					@Override
					public void checkClientTrusted(X509Certificate[] chain, String authType)
							throws CertificateException {
					}
				}
	    };
	    SSLContext ctx = null;
	    try {
	        ctx = SSLContext.getInstance("TLS");
	        ctx.init(null, certs, new SecureRandom());
	    } catch (java.security.GeneralSecurityException ex) {
	    }
	    HttpsURLConnection.setDefaultSSLSocketFactory(ctx.getSocketFactory());
	    
	    ClientConfig config = new DefaultClientConfig();
	    try {
		    config.getProperties().put(HTTPSProperties.PROPERTY_HTTPS_PROPERTIES, new HTTPSProperties(
		        new HostnameVerifier() {
					@Override
					public boolean verify(String hostname, SSLSession session) {
						return true;
					}
		        }, 
		        ctx
		    ));
	    } catch(Exception e) {
	    }
	    return config;
	}
	
	public static Client createClient() {
	    return Client.create(configureClient());
	}
	
}
