package br.com.interoperabilidade.boletos.bb.resolver;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class DadosBoletoBancario {

	private Long idConv;
	
	private String refTran;
	
	private Double valor;
	
	private Long qtdPontos;
	
	private Long dtVenc;
	
	private Long tpPagamento;
	
	private String cpfCnpj;
	
	private Long indicadorPessoa;
	
	private Double valorDesconto;
	
	private Long dataLimiteDesconto;
	
	private String tpDuplicata;
	
	private String urlRetorno;
	
	private String utlInforma;
	
	private String nome;
	
	private String endereco;
	
	private String cidade;
	
	private String uf;
	
	private String cep;
	
	private String msgLoga;

	public DadosBoletoBancario() {

	}
	
	public DadosBoletoBancario(Long idConv, String refTran, Double valor, Long qtdPontos, Long dtVenc, Long tpPagamento,
			String cpfCnpj, Long indicadorPessoa, Double valorDesconto, Long dataLimiteDesconto, String tpDuplicata,
			String urlRetorno, String utlInforma, String nome, String endereco, String cidade, String uf, String cep,
			String msgLoga) {
		super();
		this.idConv = idConv;
		this.refTran = refTran;
		this.valor = valor;
		this.qtdPontos = qtdPontos;
		this.dtVenc = dtVenc;
		this.tpPagamento = tpPagamento;
		this.cpfCnpj = cpfCnpj;
		this.indicadorPessoa = indicadorPessoa;
		this.valorDesconto = valorDesconto;
		this.dataLimiteDesconto = dataLimiteDesconto;
		this.tpDuplicata = tpDuplicata;
		this.urlRetorno = urlRetorno;
		this.utlInforma = utlInforma;
		this.nome = nome;
		this.endereco = endereco;
		this.cidade = cidade;
		this.uf = uf;
		this.cep = cep;
		this.msgLoga = msgLoga;
	}



	public Long getIdConv() {
		return idConv;
	}

	public void setIdConv(Long idConv) {
		this.idConv = idConv;
	}

	public String getRefTran() {
		return refTran;
	}

	public void setRefTran(String refTran) {
		this.refTran = refTran;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

	public Long getQtdPontos() {
		return qtdPontos;
	}

	public void setQtdPontos(Long qtdPontos) {
		this.qtdPontos = qtdPontos;
	}

	public Long getDtVenc() {
		return dtVenc;
	}

	public void setDtVenc(Long dtVenc) {
		this.dtVenc = dtVenc;
	}

	public Long getTpPagamento() {
		return tpPagamento;
	}

	public void setTpPagamento(Long tpPagamento) {
		this.tpPagamento = tpPagamento;
	}

	public String getCpfCnpj() {
		return cpfCnpj;
	}

	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	public Long getIndicadorPessoa() {
		return indicadorPessoa;
	}

	public void setIndicadorPessoa(Long indicadorPessoa) {
		this.indicadorPessoa = indicadorPessoa;
	}

	public Double getValorDesconto() {
		return valorDesconto;
	}

	public void setValorDesconto(Double valorDesconto) {
		this.valorDesconto = valorDesconto;
	}

	public Long getDataLimiteDesconto() {
		return dataLimiteDesconto;
	}

	public void setDataLimiteDesconto(Long dataLimiteDesconto) {
		this.dataLimiteDesconto = dataLimiteDesconto;
	}

	public String getTpDuplicata() {
		return tpDuplicata;
	}

	public void setTpDuplicata(String tpDuplicata) {
		this.tpDuplicata = tpDuplicata;
	}

	public String getUrlRetorno() {
		return urlRetorno;
	}

	public void setUrlRetorno(String urlRetorno) {
		this.urlRetorno = urlRetorno;
	}

	public String getUtlInforma() {
		return utlInforma;
	}

	public void setUtlInforma(String utlInforma) {
		this.utlInforma = utlInforma;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getMsgLoga() {
		return msgLoga;
	}

	public void setMsgLoga(String msgLoga) {
		this.msgLoga = msgLoga;
	}
	
	
	
}
