package br.com.interoperabilidade.boletos.bb.util;



import javax.ejb.Stateless;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

import br.com.interoperabilidade.boletos.bb.resolver.DadosBoletoBancario;

@Stateless
public class ClientWebServiceUtil {

	
	public static void realizaRequisiçãoEnvio(DadosBoletoBancario dadosBoletoBancario){

		Client client = ClientBuilder.newClient();
		 WebTarget target = client.target("https://mpag.bb.com.br/site/mpag");
		 target.request(MediaType.APPLICATION_XML).post(Entity.entity(dadosBoletoBancario, MediaType.APPLICATION_XML));
		 
	}
}
