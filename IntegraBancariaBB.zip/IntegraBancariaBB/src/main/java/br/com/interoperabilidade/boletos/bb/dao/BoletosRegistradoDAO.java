package br.com.interoperabilidade.boletos.bb.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
@Local
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW )
public class BoletosRegistradoDAO <E> {
	
	@PersistenceContext(unitName="eatInterfacePU")
	private EntityManager em;
	
	public E create(E e) {
		this.em.persist(e);
		return e;
	}
	


	public E update(E e) {
		return (E) this.em.merge(e);
	}
	
	public void delete(Object id, Class<E> type) {
		Object ref = this.em.getReference(type, id);
	    this.em.remove(ref);
	}
	
	public E find(Object id, Class<E> type) {
		return (E) this.em.find(type, id);
	}




	@SuppressWarnings("unchecked")
	public List<E> findByNamedQuery(String namedQueryName) {
		List<E> results = null;
		results = this.em.createNamedQuery(namedQueryName).getResultList();
		return  results;
	}

	public List<E> findByNamedQuery(String namedQueryName, Map<String, Object> parameters) {
		List<E> results = null;
		results = (List<E>) findByNamedQuery(namedQueryName, parameters, 0);
		return results;
	}

	@SuppressWarnings("unchecked")
	public List<E> findByNamedQuery(String queryName, int resultLimit) {
		List<E> results = null;
		results = (List<E>) this.em.createNamedQuery(queryName).setMaxResults(resultLimit).getResultList();
		return results;
	}

	@SuppressWarnings("unchecked")
	public List<E> findByNamedQuery(String namedQueryName, Map<String, Object> parameters, int resultLimit) {
		Set<Entry<String, Object>> rawParameters = parameters.entrySet();
		Query query = this.em.createNamedQuery(namedQueryName);
		if (resultLimit > 0)
			query.setMaxResults(resultLimit);
		for (Entry<String, Object> entry : rawParameters) {
			query.setParameter(entry.getKey(), entry.getValue());
		}
		List<E> results = null;
		results = (List<E>) query.getResultList();
		return results;
	}

}
