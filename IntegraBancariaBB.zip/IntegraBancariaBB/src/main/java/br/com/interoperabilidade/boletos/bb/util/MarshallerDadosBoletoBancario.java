package br.com.interoperabilidade.boletos.bb.util;

import java.io.StringWriter;
import java.util.List;

import javax.ejb.Stateless;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import br.com.interoperabilidade.boletos.bb.resolver.DadosBoletoBancario;

@Stateless
public class MarshallerDadosBoletoBancario {

	public String marshaller(List<DadosBoletoBancario> listDadosBoletoBancario){
		StringWriter out = new StringWriter();
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(DadosBoletoBancario.class);
			Marshaller marshaller = jaxbContext.createMarshaller();
			
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			
			marshaller.marshal(listDadosBoletoBancario,out);
			
			return out.toString();
			
		} catch (JAXBException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public String marshallerTeste(DadosBoletoBancario listDadosBoletoBancario){
		StringWriter out = new StringWriter();
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(DadosBoletoBancario.class);
			Marshaller marshaller = jaxbContext.createMarshaller();
			
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			
			marshaller.marshal(listDadosBoletoBancario,out);
			
			return out.toString();
			
		} catch (JAXBException e) {
			e.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
}
